/*************************ParameterManager.c****************************
Student Name: Erik Zorn - Wallentin  Student Number: 0864583
Date: Thur, Jan.22 / 2015            Course Name: CIS2750
I have exclusive control over this submission via my password.
By including this statement in this header comment, I certify that:
1) I have read and understood the University policy on academic integrity;
2) I have completed the Computing with Integrity Tutorial on Moodle; and
3) I have achieved at least 80% in the Computing with Integrity Self Test.
I assert that this work is my own. I have appropriately acknowledged any and all material
(data, images, ideas or words) that I have used, whether directly quoted or paraphrased.
Furthermore, I certify that this assignment was prepared by me specifically for this course.
****************************************************************************/

#include "ParameterManager.h"

ParameterManager * PM_create(int size)
{
	ParameterManager * createTable;
	int i = 0;
	
	/* Has to be a positive integer value */
	if (size < 1)
	{
		fprintf(stderr, "Create ERROR in PM_create: Has to be a positive integer (above 0)!\n");
		return NULL;
	}
	
	/* Allocate memory for the hash table structure */
	createTable = malloc(sizeof(ParameterManager));
	if (createTable == NULL)
	{
		fprintf(stderr, "Create ERROR in PM_create: Could not allocate memory for hash table structure!\n");
		return NULL;
	}
	
	/* Allocate memory for the hash table */
	createTable->hashTable = malloc(sizeof(ParameterManagerList *) * size);
	if (createTable->hashTable == NULL)
	{
		fprintf(stderr, "Create ERROR in PM_create: Could not allocate memory for hash table!\n");
		return NULL;
	}
	
	/* Initialize elements in the hash table */
	for (i = 0; i < size; i++) 
	{
		createTable->hashTable[i] = '\0';
	}
	
	/* Set the table size */
	createTable->size = size;
	
	createTable->params = malloc(sizeof(char) * 500);
	if (createTable->params == NULL)
	{
		fprintf(stderr, "Create ERROR in PM_create: Could not allocate memory for params!\n");
		return NULL;
	}
	
	return createTable;
}

int PM_destroy(ParameterManager * p)
{
	ParameterManagerList * tempList;
	ParameterManagerList * tempVar;
	int n = 0;
	
	if (p == NULL)
	{
		fprintf(stderr, "Create ERROR in PM_destroy: Create space for your ParameterManager variable!\n");
		return 0; /* Not a success */
	}
	
	/* Free all the elements in the list */
	for (n = 0; n < p->size; n++)
	{
		tempList = p->hashTable[n];
		while(tempList != NULL)
		{
			tempVar = tempList;
			tempList = tempList->next;
			free(tempVar->name);
			free(tempVar);
		}
	 }
    
	/* Free up the table */
	free(p->params);
	free(p->hashTable);
	free(p);
    
	/* Return 1 to indicate a success */
	return 1;
}

unsigned int hashFunc(ParameterManager * p, char * pname)
{
	unsigned int hashResult = 0;
	int n = 0;
    
	for (n = 0; n < strlen(pname); n++)
	{
		hashResult += pname[n];
	}

	/* MOD result so it can fit into the correct range */
	return (hashResult % p->size);
}


ParameterManagerList * findElement(ParameterManager * p, char * pname, unsigned int hashResult)
{
	ParameterManagerList * createList;
    
	/* Check if pname is in the list based on the hash value */
	if (p == NULL)
	{
		fprintf(stderr, "Create ERROR in findElement: Create space for your ParameterManager variable!\n");
		return NULL;
	}

	for(createList = p->hashTable[hashResult]; createList != NULL; createList = createList->next)
	{
		if (strcmp(pname, createList->name) == 0)
		{
			/*printf("Key is already in here..\n"); */
			return createList;
		}
	}
	
	return NULL;
}

int PM_manage(ParameterManager * p, char * pname, param_t ptype, int required)
{
	
	ParameterManagerList * createList;
	ParameterManagerList * oldList;
	int j = 0;
	int requiredResult = 0; 
	
	if (p == NULL)
	{
		fprintf(stderr, "Create ERROR in PM_manage: Create space for your ParameterManager variable!\n");
		return 0;
	}
	
	/* Check if there is a valid param_t ptype */
	if (ptype != INT_TYPE && ptype != REAL_TYPE && ptype != BOOLEAN_TYPE && ptype != STRING_TYPE && ptype != LIST_TYPE )
	{
		fprintf(stderr, "Create ERROR in PM_manage: Incorrect Parameter type!\n");
		return 0;
	}
    
	/* Check if there is a space in parameter name */
	for (j = 0; j < strlen(pname); j++)
	{
	  if (pname[j] == ' ')
	  {
	  	fprintf(stderr, "Create ERROR in PM_manage: Parameter name cannot have spaces!\n");
		return 0;
	  }
	}
	
	/* If required is not 0, convert it always to value 1 as the default value to say it is required for future use! */
	if (required > 0 || required < 0)
	{
		requiredResult = 1;
	}
	
	unsigned int hashValue = hashFunc(p, pname);
	/*printf("Hash Value = %d\n", hashValue);*/
	
	/* Allocate memory for the list */
	createList = malloc(sizeof(ParameterManagerList));
	if (createList == NULL)
	{
		fprintf(stderr, "Manage ERROR: Memory allocation error!\n");
		return 0;
	}
	
	/* Check if item already exists */
	oldList = findElement(p, pname, hashValue);
	
	/* item already exists, don't insert it again. */
	if (oldList != NULL)
	{
		fprintf(stderr, "Manage ERROR: Parameter already exists!\n");
		return 0;
	}
	/* Item does not exist, so we will insert it */
	else
	{
		createList->name = strdup(pname);
		createList->type = ptype;
		createList->flag = required;
		createList->assigned = false;
		//createList->value = 0;
		createList->next = p->hashTable[hashValue];
		p->hashTable[hashValue] = createList;
		
		
		strcat(p->params, pname);
		strcat(p->params, ",");
	}
	
	return 1;
}

int PM_hasValue(ParameterManager * p, char * pname)
{
	ParameterManagerList * tempList;
	int j = 0;
	
	if (p == NULL)
	{
		fprintf(stderr, "ERROR in PM_hasValue: Create space for your ParameterManager variable!\n");
		return 0;
	}
	
	/* Check if there is a space in parameter name */
	for (j = 0; j < strlen(pname); j++)
	{
		if (pname[j] == ' ')
		{
			fprintf(stderr, "ERROR in PM_hasValue: Parameter name cannot have spaces!\n");
			return 0;
		}
	}
	
	unsigned int hashValue = hashFunc(p, pname);
	
	/* Check if item already exists */
	tempList = findElement(p, pname, hashValue);

	/* item already exists, don't insert it again. */
	if (tempList != NULL)
	{
		if(tempList->assigned == true)
		{
			return 1;
		}
	}
    
	return 0; /* No value, or unknown parameter */
}

ParameterList * reverse(ParameterList * head)
{
	ParameterList * temp = NULL;
	ParameterList * prev = NULL;
	
	while (head != NULL)
	{
		temp = head->next;
		head->next = prev;
		prev = head;
		head = temp;
		
	}
	return prev;

}

/* void insertElement(ParameterList * head, char * element) */
ParameterList * insertElement(ParameterList * head, char * element)
{       
	ParameterList * newNode;
    
	newNode =(ParameterList *)malloc(sizeof(ParameterList));
	newNode->str = malloc(strlen(element)+1);
    
	 if (newNode == NULL)
	{
		return NULL;
	}
    
	strcpy(newNode->str, element);
	newNode->flag = false;
	newNode->next = head;
	head = newNode;
    
	return (newNode);
}

union param_value PM_getValue(ParameterManager * p, char * pname)
{
	union param_value value;
	ParameterManagerList * tempList;
	unsigned int hashValue = 0;
	int j = 0;
	
	char * buffer = malloc(sizeof(char));
	int sizeOfBuffer = 0;
	char * tempString = "";
	
	ParameterList * head = NULL;
	
	if (p == NULL)
	{
		fprintf(stderr, "Create ERROR in PM_getValue Func: Create space for your ParameterManager variable!\n");
		value.int_val = 0;
		free(buffer);
		return value;
	}
	
	/* Check if there is a space in parameter name */
	for (j = 0; j < strlen(pname); j++)
	{
		if (pname[j] == ' ')
		{
			fprintf(stderr, "ERROR in PM_getValue: Parameter name cannot have spaces!\n");
			value.int_val = 0;
			free(buffer);
			return value;
		}
	}
	
	j = 0;
	
	hashValue = hashFunc(p, pname);
	tempList = findElement(p, pname, hashValue);

	/* Found item so return its value */
	if (tempList != NULL)
	{
		if (tempList->type == LIST_TYPE)
		{
			tempString = tempList->value.str_val;
    		
			/*printf("'%s'\n", tempString);*/
    		
			/* Check if there is a space in parameter name */
			for (j = 0; j < strlen(tempString); j++)
			{
				if (tempString[j] == ',')
	  			{
	  				printf("BUFFER: '%s'\n", buffer);
	  				head = insertElement(head, buffer);
	  				printf("AFTERR INSERT: %s\n", head->str);
	  				
					memset(buffer, 0, sizeof (char*));
					sizeOfBuffer = 0;
	  			}
	  			else
	  			{
	  				buffer = (char*)realloc(buffer, sizeOfBuffer+1);
					buffer[sizeOfBuffer] = tempString[j];
					sizeOfBuffer++;
	  			}
			}
			
			printf("BUFFER: '%s'\n", buffer);
	  		head = insertElement(head, buffer);
	  		printf("AFTERR INSERT: %s\n", head->str);
	  			
			memset(buffer, 0, sizeof (char*));
			sizeOfBuffer = 0;
    		
    		
			head = reverse(head);
			value.list_val = head;
		}
		else
		{
			value = tempList->value;
		}
    	
		free(buffer);
		return value;	
	}
	else
	{
		value.int_val = 0;
		free(buffer);
		return value;
	}
}

char * PL_next(ParameterList * l)
{	
	if (l == NULL)
	{
		return NULL;
	}
	
	while (l != NULL)
	{
		printf("CHECK1**Value: %s**, **Flag: %d\n", l->str, l->flag);
		if (l->flag == false)
		{
			l->flag = true;
			printf("CHECK2**Value: %s**, **Flag: %d\n", l->str, l->flag);
			return (l->str);
		}
		else
		{
			l = l->next;
		}
	}
	return NULL;
}

int PM_parseFrom(ParameterManager *p, FILE * fp, char comment)
{
	int c;
	int j = 0;
	
	char * buffer1 = malloc(sizeof(char));
	int sizeOfBuffer1 = 0;
	
	char * buffer2 = malloc(sizeof(char));
	int sizeOfBuffer2 = 0;
	
	Boolean flag = false;
	Boolean checkSpace = false;
	int checkQuotes = 0;
	Boolean ignoreFirstQuote = true;
	Boolean parseFlag = false; /* Set to throw an error if there is any space in parameter */
	
	Boolean checkBracket1 = false;
	Boolean checkBracket2 = false;
	Boolean bracketMode = false;
	int checkBracketQuotes = 0;
	
	Boolean checkEquals = false;
	
	
	ParameterManagerList * tempList;
	unsigned int hashValue = 0;
	
	if (p == NULL)
	{
		fprintf(stderr, "Create ERROR in PM_parseFrom: Create space for your ParameterManager variable!\n");
		free(buffer1);
		free(buffer2);
		return 0; /* Error with parameter manager variable */
	}

    c = fgetc(fp);
    while (c != EOF) 
    {
    	if ( !isspace(c))
    	{
    		/* Eat everything when you get the comment variable from user */
    		if (c == comment && checkQuotes != 1 && checkBracketQuotes != 1) 
    		{
    			while (c != '\n' && c != EOF)
    			{
    				c = fgetc(fp);
    			}
    			ungetc(c,fp);
    		}
    		
    		/* Setup first variable */
    		else if (c == '=')
    		{	
			if (checkEquals == true)
			{
			    fprintf(stderr, "PARSE ERROR: Too many equals in - ('%s')!\n", buffer2);
			    free(buffer1);
			    free(buffer2);
			    return 0;
			}
		  
    			flag = true; /* Set the flag */
    			checkEquals = true;
    			
    			/* Reset Flags */
    			parseFlag = false;
    			checkSpace = false;
    		}
    		else if (c == ';')
    		{	
				if (checkQuotes == 1)
    			{
    				fprintf(stderr, "PARSE ERROR: There is a missing quote in string - ('%s')!\n", buffer2);
    				free(buffer1);
				free(buffer2);
    				return 0;
    			}
    			else if ((checkBracket1 == true && checkBracket2 == false) || (checkBracket1 == false && checkBracket2 == true))
    			{
    				fprintf(stderr, "PARSE ERROR: There is a bracket open!\n");
    				free(buffer1);
					free(buffer2);
    				return 0;	
    			}
				
				/*printf("'%s'\n", buffer1);*/
				/*printf("'%s'\n", buffer2);*/
	
				hashValue = hashFunc(p, buffer1);
				/*printf("Hash Value = %d\n", hashValue);*/
	
				/* Check if item already exists */
				tempList = findElement(p, buffer1, hashValue);

    			/* item already exists, don't insert it again. */
   				if (tempList != NULL)
    			{
    				/*printf("THIS EXISTS: %s\n", tempList->name); */
					if(tempList->type == INT_TYPE)
					{	 
						/* Check if there is a char in parameter value */
						for (j = 0; j < strlen(buffer2); j++)
						{
	  						if (buffer2[j] != '1' && buffer2[j] != '2' && buffer2[j] != '3' && buffer2[j] != '4' && buffer2[j] != '5' &&
	  							buffer2[j] != '6' && buffer2[j] != '7' && buffer2[j] != '8' && buffer2[j] != '9' && buffer2[j] != '0'
	  							&& buffer2[j] != '-' && buffer2[j] != '+')
	  						{
	  							fprintf(stderr, "PARSE ERROR: Parameter value is not a proper integer value - ('%s')!\n", buffer2);
    							free(buffer1);
								free(buffer2);
    							return 0;
	  						}
						}
						
						tempList->value.int_val = atoi(buffer2);
					}
					else if(tempList->type == STRING_TYPE)
					{
						if (checkQuotes != 2)
						{
							fprintf(stderr, "PARSE ERROR: Parameter is a string type and needs to have quotes around it - ('%s')!\n", buffer1);
    						free(buffer1);
							free(buffer2);
    						return 0;
						}		
						tempList->value.str_val = strdup(buffer2);
					}
					else if(tempList->type == BOOLEAN_TYPE)
					{
						/*printf("BOOLEAN TYPE: %s\n", buffer2);*/
						if (strcmp("true", buffer2) == 0)
						{
							tempList->value.bool_val = true;
						}
						else if (strcmp("false", buffer2) == 0)
						{
							tempList->value.bool_val = false;
						}
						else
						{
							fprintf(stderr, "PARSE ERROR: Parameter is a boolean type and need to be true or false - ('%s')!\n", buffer1);
    						free(buffer1);
							free(buffer2);
    						return 0;
						}
						
					}
					else if(tempList->type == REAL_TYPE)
					{	
						/* Check if there is a char in parameter value */
						for (j = 0; j < strlen(buffer2); j++)
						{
	  						if (buffer2[j] != '1' && buffer2[j] != '2' && buffer2[j] != '3' && buffer2[j] != '4' && buffer2[j] != '5' &&
	  							buffer2[j] != '6' && buffer2[j] != '7' && buffer2[j] != '8' && buffer2[j] != '9' && buffer2[j] != '0' &&
	  							buffer2[j] != '.' && buffer2[j] != '-' && buffer2[j] != '+')
	  						{
	  							fprintf(stderr, "PARSE ERROR: Parameter value is not a proper float value - ('%s')!\n", buffer2);
    							free(buffer1);
								free(buffer2);
    							return 0;
	  						}
						}
							
						float number = 0.0;
						
						sscanf(buffer2, "%f", &number);
						/*printf("%f\n", number);*/
						
						tempList->value.real_val = number;
						
					}
					else if(tempList->type == LIST_TYPE)
					{
						/*printf("LIST TYPE: %s\n", buffer2);*/
						
						if (checkBracket1 == false || checkBracket2 == false || checkQuotes != 0)
						{
							fprintf(stderr, "PARSE ERROR: Parameter value is not a proper list value - ('%s')!\n", buffer1);
							free(buffer1);
							free(buffer2);
    						return 0;
						}
						printf("\n !!!PARSE INTO IT: %s!!!\n", buffer2);
						tempList->value.str_val = strdup(buffer2);

					}
					
					/* Variable was assigned for the hasValue function */
					tempList->assigned = true;
    			}
    			
    			/* Reset Flags */
    			flag = false;
    			parseFlag = false;
    			checkSpace = false;
    			checkQuotes = 0;
    			ignoreFirstQuote = true;
    			
    			checkBracket1 = false;
    			checkBracket2 = false;
    			bracketMode = false;
    			checkBracketQuotes = 0;
    			j = 0;
			
			checkEquals = false;
    			
    			/* Clear everything after done one parameter and reset buffer counters */
    			memset(buffer1, 0, sizeof (char*));
    			sizeOfBuffer1 = 0;
	
    			memset(buffer2, 0, sizeof (char*));
    			sizeOfBuffer2 = 0;
    		}
    		else
    		{
    			/* Setup variable BEFORE the "=" 
    		   	   Find key that matches everything before = */
    			if (flag == false)
    			{
    				if (parseFlag == true)
    				{
    					fprintf(stderr, "PARSE ERROR: There is a space with stuff in the parameter - ('%s')!\n", buffer1);
    					free(buffer1);
						free(buffer2);
    					return 0;
    				}
					buffer1 = (char*)realloc(buffer1, sizeOfBuffer1+1);
					buffer1[sizeOfBuffer1] = c;
					sizeOfBuffer1++;
					//printf("'%s'\n", tester3);
					
					/* if you get any spaces now throw an error*/
					checkSpace = true;
    			}
    			/* Setup variable AFTER the "=" 
    		   	   Find key that matches everything before = */
    			else if (flag == true)
    			{
    				if ( c == '{')
    				{
    					if (checkBracket1 == true)
						{
							fprintf(stderr, "PARSE ERROR: Bracket error in list type!\n");
							free(buffer1);
							free(buffer2);
							return 0;
						}
    					checkBracket1 = true;
    					bracketMode = true;
    				}
    				else if (c == '}')
					{
							if (checkBracket1 == false || checkBracket2 == true)
							{
								fprintf(stderr, "PARSE ERROR: Bracket error in list type!\n");
								free(buffer1);
								free(buffer2);
								return 0;
							}
							checkBracket2 = true;
							bracketMode = false;
					}
    				/* Do all list parsing here ! */
    				else if (bracketMode == true)
    				{
    					if (checkQuotes > 0 || parseFlag == true || checkSpace == true)
    					{
    						fprintf(stderr, "PARSE ERROR: Incorrect input into list type!\n");
							free(buffer1);
							free(buffer2);
							return 0;
    					}
    				
						/* Check the bracket quotes and count them */
						if(c == '"')
						{
							checkBracketQuotes++;	
						}
						
						else if (c == ',')
						{
							if (checkBracketQuotes <= 1 || checkBracketQuotes > 2)
							{
								fprintf(stderr, "PARSE ERROR: There are too many, not enough quotes, or too many comma's in the list value!\n");
								free(buffer1);
								free(buffer2);
								return 0;
							}
							else
							{
								/* Check the " " here! */
								/* Reset the quotes */
								checkBracketQuotes = 0;
								
								buffer2 = (char*)realloc(buffer2, sizeOfBuffer2+1);
								buffer2[sizeOfBuffer2] = c;
								sizeOfBuffer2++;
								
							}
						}
						else
						{
							if (checkBracketQuotes == 0 || checkBracketQuotes >= 2)
							{
								fprintf(stderr, "PARSE ERROR: Incorrect way to input data, make sure to use quotes for data!\n");
								free(buffer1);
								free(buffer2);
								return 0;
							}
							buffer2 = (char*)realloc(buffer2, sizeOfBuffer2+1);
							buffer2[sizeOfBuffer2] = c;
							sizeOfBuffer2++;
						}
    				}
    				/* Every other parsing after "=" is done here */
    				else
    				{
						if (checkQuotes >= 2)
						{
							fprintf(stderr, "PARSE ERROR: There is a space or too many quotes in the value - ('%s')!\n", buffer2);
							free(buffer1);
							free(buffer2);
							return 0;
						}
					
						if(c == '"')
						{
							checkQuotes++;	
						}
					
						if (parseFlag == true && checkSpace == true)
						{
							fprintf(stderr, "PARSE ERROR: There is a space with stuff in the value - ('%s')!\n", buffer2);
							free(buffer1);
							free(buffer2);
							return 0;
						}
						else if (checkSpace == true && checkQuotes > 0)
						{
							fprintf(stderr, "PARSE ERROR: There is a quote in incorrect value - ('%s')!\n", buffer2);
							free(buffer1);
							free(buffer2);
							return 0;
						}
						else if (checkBracket1 == true || checkBracket2 == true)
						{
							fprintf(stderr, "PARSE ERROR: Incorrect input on list type!\n");
							free(buffer1);
							free(buffer2);
							return 0;
						}
					
						/* You are inside a string with an open quote ("  ) */
						if (checkQuotes == 1)
						{
							//checkSpace = false;
							if (ignoreFirstQuote == false)
							{
								buffer2 = (char*)realloc(buffer2, sizeOfBuffer2+1);
								buffer2[sizeOfBuffer2] = c;
								sizeOfBuffer2++;
							}
							ignoreFirstQuote = false;
						}
						/* You are using a normal value that is not a string */
						else if (checkQuotes == 0)
						{
							buffer2 = (char*)realloc(buffer2, sizeOfBuffer2+1);
							buffer2[sizeOfBuffer2] = c;
							sizeOfBuffer2++;
						
							checkSpace = true;
						}
					}		
    			}
    		}
        }
        
	/* All white space checking is done here, sets parse flags and checks for string value */
        else
        {
        	if (checkSpace == true)
        	{
			parseFlag = true; /* Set to throw an error if there is any space in parameter */
        	}
        	
        	/* Need this to check for spaces inside a string value (Ex. "Bill Jones")
        	   If you don't do this you will get (Ex. "BillJones") */
        	if (flag == true && checkQuotes == 1)
        	{
        		buffer2 = (char*)realloc(buffer2, sizeOfBuffer2+1);
			buffer2[sizeOfBuffer2] = c;
			sizeOfBuffer2++;
        	}
        	/* Check spaces inside the list quotes! */
        	else if (bracketMode == true && checkBracketQuotes == 1)
        	{
        		buffer2 = (char*)realloc(buffer2, sizeOfBuffer2+1);
			buffer2[sizeOfBuffer2] = c;
			sizeOfBuffer2++;
        	}
        }
        c = fgetc(fp);
	
	}
	
	if (flag == true || parseFlag == true || checkSpace == true)
	{
		fprintf(stderr, "PARSE ERROR: No semicolon found in - ('%s')!\n", buffer2);
		free(buffer1);
		free(buffer2);
		return 0; 
	}
    
	/* Check all required parameters were met! */
	ParameterManagerList * tempParams;
	hashValue = 0;
    
	/* Check if there is a space in parameter name */
	for (j = 0; j < strlen(p->params); j++)
	{
		if (p->params[j] == ',')
	  	{
			hashValue = hashFunc(p, buffer2);
			tempParams = findElement(p, buffer2, hashValue);
			
			if (tempParams != NULL)
			{
				if (tempParams->flag == 1)
				{
					if (!PM_hasValue(p, buffer2))
					{
						fprintf(stderr, "PARSE ERROR: Required parameter value was not given for - ('%s')!\n", buffer2);
						free(buffer1);
						free(buffer2);
						return 0;
					}
				}
			}
			
		memset(buffer2, 0, sizeof (char*));
    		sizeOfBuffer2 = 0;
	  	}
	  	
		else
	  	{
	  		buffer2 = (char*)realloc(buffer2, sizeOfBuffer2+1);
			buffer2[sizeOfBuffer2] = p->params[j];
			sizeOfBuffer2++;
	  	}
	}
	
	memset(buffer2, 0, sizeof (char*));
	sizeOfBuffer2 = 0;
    
	/* Free all memory here */
	free(buffer1);
	free(buffer2);
	return 1;
}

