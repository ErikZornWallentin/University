CIS2750W15 A1 Test
===

A framework for testing assignment 1 of CIS2750W15 at the University of Guelph.

Testing
---

1. Clone this repository on one of the socs.uoguelph.ca servers.
2. Copy the contents of this repository into the repository to be tested.
3. Run `make` to compile the libpm.a library.
4. Run `make -f TestMake` to build the testing tool.
5. Run `make -f TestMake test` to test the library.
