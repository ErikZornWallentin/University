****************************************************
Erik Zorn-Wallentin	 0864583
CIS2750			     2750W15_A1
Thursday, Jan. 23 / 2015
****************************************************

**********************
Compilation
**********************

I gave files: a1config.txt as an input stream, and a1example.c as a main to show the library working.

To compile this program make sure you are in the correct directory in the terminal for where your file is.
Next type make in the command prompt.

After you type make it will create a static library file called libpm.a
To use this libpm.a a possible command could be:
gcc -o output a1example.c libpm.a

Remember to use the libpm.a file and "output" with be the executable, after you can run as:
./output < a1config.txt      Where the a1config.txt is a stdin stream for a file.

***********************
Running the program(s)
***********************

This is a library with several different functions, some functions that the user can use are:

ParameterManager * PM_create(int size);
- Which allows you to create a size for the hash table

int PM_destroy(ParameterManager * p);
- Destroys the current hash table

int PM_parseFrom(ParameterManager * p, FILE * fp, char comment);
- Parses the data from stdin / file, and also allows you to add comment for the file

int PM_manage(ParameterManager * p, char * pname, param_t ptype, int required);
- Creates the parameter

int PM_hasValue(ParameterManager * p, char * pname);
- Checks if the parameter has a value

union param_value PM_getValue(ParameterManager * p, char * pname);
- Assigns the parameter value to a variable

char * PL_next(ParameterList * l);
- Returns the next element in the list


More detailed descriptions of functions will be given in the ParameterManager.h file

For the pre-post conditions of any function, comments were given inside the functions to show what is happening


**************************
Bibliography / References
**************************
http://www.sparknotes.com/cs/searching/hashtables/section3.rhtml -- understanding hash table

*****************
Known Limitations
*****************

Your parameter names given, out of entire program the max it can hold is 500 characters total of all parameters together,
if it goes beyond that the program will crash.

Empty list is not considered NULL list, it is just empty variable being "".


