/*************************ParameterManager.h****************************
Student Name: Erik Zorn - Wallentin  Student Number: 0864583
Date: Thur, Jan.22 / 2015            Course Name: CIS2750
I have exclusive control over this submission via my password.
By including this statement in this header comment, I certify that:
1) I have read and understood the University policy on academic integrity;
2) I have completed the Computing with Integrity Tutorial on Moodle; and
3) I have achieved at least 80% in the Computing with Integrity Self Test.
I assert that this work is my own. I have appropriately acknowledged any and all material
(data, images, ideas or words) that I have used, whether directly quoted or paraphrased.
Furthermore, I certify that this assignment was prepared by me specifically for this course.
****************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

/* Comment for programming at my house: set PATH=C:\MinGW\bin;%PATH% */

/* Declare my constants */
typedef enum {INT_TYPE, REAL_TYPE, BOOLEAN_TYPE, STRING_TYPE, LIST_TYPE} param_t;

/* Declare Boolean ADT */
typedef int Boolean;
#define true 1
#define false 0

/* List that contains elements of a LIST_TYPE */
struct paramList
{
    char * str;
    struct paramList * next;
    Boolean flag;
};
typedef struct paramList ParameterList;

/* Allows the value of parameter to be stored in the same field regardless of type */
union param_value
{
	int int_val;
	float real_val;
	Boolean bool_val;
	char *str_val;
	ParameterList *list_val;
};

/* Struct for ParameterList Variable, it contains the name of the parameter, value, assigned value,
   type of the variable, if it is required or not */
struct paramManagerList
{
    char * name;
    union param_value value;
    int flag;
    param_t type;
    Boolean assigned;
    struct paramManagerList * next;
};
typedef struct paramManagerList ParameterManagerList;


/* Struct for ParameterManager Variable, using hash table */
/* We don't know designated size so its a dynamic array (**) */
/* Hash table search in O(1) time which is constant ! */
struct paramManager
{
    int size;						/* Size of the hash table */
    char * params;
    ParameterManagerList ** hashTable; 	/* The table of elements */
};
typedef struct paramManager ParameterManager;

/*-------
Purpose: A function that hashes the parameter name into a value that we can search for later
Parameters: ParameterManager * p (takes in the parameter to manage), char * pname (parameter name)
Return: hashed value of parameter name
-------*/
unsigned int hashFunc(ParameterManager * p, char * pname);

/*-------
Purpose: A function that finds an element in the hash table using the hash value and parameter name
Parameters: ParameterManager * p (takes in the parameter to manage), char * pname (parameter name), int hashResult (hash value of pname)
Return: The found element if it finds something.
-------*/
ParameterManagerList * findElement(ParameterManager * p, char * pname, unsigned int hashResult);

/*-------
Purpose: A function that allocates space for the hash table
Parameters: int size (the value to allocate size for)
Return: Hash table with allocated space
-------*/
ParameterManager * PM_create(int size);

/*-------
Purpose: A function that deletes everything with the ParameterManager variable
Parameters: ParameterManager * p (takes in the parameter to manage)
Return: int (success or failure value)
-------*/
int PM_destroy(ParameterManager * p);

/*-------
Purpose: A function that parses all the data from stdin into the parameters
Parameters: ParameterManager * p (takes in the parameter to manage), FILE * fp (stdin to parse from), char comment (comment given by user that will indicate to ignore)
Return: int (success or failure value)
-------*/
int PM_parseFrom(ParameterManager * p, FILE * fp, char comment);

/*-------
Purpose: A function that sets up parameters in the hash table
Parameters: ParameterManager * p (takes in the parameter to manage), param_t ptype (the type of parameter), int required (if parameter is required or not)
Return: int (success or failure value)
-------*/
int PM_manage(ParameterManager * p, char * pname, param_t ptype, int required);

/*-------
Purpose: A function that checks if parameter has a value or not associated with it
Parameters: ParameterManager * p (takes in the parameter to manage), char * pname (the parameter to check for)
Return: int (success or failure value)
-------*/
int PM_hasValue(ParameterManager * p, char * pname);

/*-------
Purpose: A function that assigns the value of parameter to a variable that the user chooses
Parameters: ParameterManager * p (takes in the parameter to manage), char * pname (the parameter to check for)
Return: The type of parameter into the variable
-------*/
union param_value PM_getValue(ParameterManager * p, char * pname);

/*-------
Purpose: A function that returns the next element in the list type parameter
Parameters: ParameterList * l (the parameter list type )
Return: The next element in the list type variable
-------*/
char * PL_next(ParameterList * l);


/*-------
Purpose: A function that adds an element to the singly linked list
Parameters: ParameterList * root (the head of parameter list type ), char * element (element to add to list)
Return: ParameterList * (head of the reversed list)
-------*/
ParameterList * insertElement(ParameterList * head, char * element);
/*void insertElement(ParameterList * head, char * element); */


/*-------
Purpose: A function that reverses the singly linked list
Parameters: ParameterList * root (the head of parameter list type )
Return: ParameterList * (head of the reversed list)
-------*/
ParameterList * reverse(ParameterList * root);